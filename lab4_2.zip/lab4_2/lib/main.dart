import 'package:flutter/material.dart';
import 'neon_button.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Project',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        backgroundColor: Colors.black,
        body:  Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [ neonButton(Colors.red),
            neonButton(Colors.greenAccent.shade100),
            neonButton(Colors.blueAccent.shade400),
            neonButton(Colors.yellowAccent.shade400),
             neonButton(Colors.blue),
             neonButton(Colors.white),
           SpinKitCircle(
          size: 140,
          itemBuilder: (context, index) {
            final colors = [Colors.green, Colors.red, Colors.yellow];
            final color = colors[index % colors.length];
            return DecoratedBox(decoration: BoxDecoration(color: color,shape: BoxShape.circle));
          },
        )
],),
            // child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            // children: [const neonButton(Colors.red),
            // neonButton(Colors.greenAccent.shade100),
            // neonButton(Colors.blueAccent.shade400),
            // neonButton(Colors.yellowAccent.shade400),
            // const neonButton(Colors.blue),
            // const neonButton(Colors.white),],),

            // child: Listener(
            //   onPointerDown: (e) => setState(() {
            //     isPressed = true;
            //   }),
            //   onPointerUp: (e) => setState(() {
            //     isPressed = false;
            //   }),
            //   child: Container(
            //     decoration: BoxDecoration(
            //         borderRadius: BorderRadius.circular(10),
            //         boxShadow: [
            //           for (double i = 1; i < 5; i++)
            //             BoxShadow(
            //                 color: shadowColor,
            //                 blurRadius: (isPressed ? 5 : 3) * i,
            //                 blurStyle: BlurStyle.outer),
            //         ]),
            //     child: TextButton(
            //       onHover: (hovered) => setState(() {
            //         isPressed = hovered;
            //       }),
            //       style: TextButton.styleFrom(
            //           side: const BorderSide(color: Colors.white, width: 4),
            //           shape: RoundedRectangleBorder(
            //               borderRadius: BorderRadius.circular(10))),
            //       onPressed: () {},
            //       child: Padding(
            //         padding: const EdgeInsets.all(8.0),
            //         child: Text(
            //           'Neon Button',
            //           style:
            //               TextStyle(fontSize: 30, color: Colors.white, shadows: [
            //             for (double i = 1; i < (isPressed ? 8 : 4); i++)
            //               Shadow(color: shadowColor, blurRadius: 3 * i),
            //           ]),
            //         ),
            //       ),
            //     ),
            //   ),
            // ),
            ));
  }
}
